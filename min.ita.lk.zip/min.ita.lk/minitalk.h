/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minitalk.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/18 23:54:55 by alaftah           #+#    #+#             */
/*   Updated: 2022/04/21 04:30:31 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINITALK_H
# define MINITALK_H

# include <signal.h>
# include<stdlib.h>
# include<string.h>
# include<stdio.h>
# include<unistd.h>
# include<fcntl.h>
# include<ctype.h>
# include<stdarg.h>	

int		ft_atoi(const char *str);
int        ft_putstr(char *s);
int        ft_printf(const char *s1, ...);
#endif
