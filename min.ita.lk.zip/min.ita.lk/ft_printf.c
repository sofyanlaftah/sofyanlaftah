/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/21 04:04:27 by alaftah           #+#    #+#             */
/*   Updated: 2022/04/21 23:13:58 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minitalk.h"

static int    hexlen3(int nbr)
{
    int    idx;

    idx = 0;
    if (nbr == 0)
        return (1);
    if (nbr < 0)
    {
        idx++;
        nbr *= -1;
    }
    while (nbr)
    {
        nbr = nbr / 10;
        idx++;
    }
    return (idx);
}

int    ft_putnbr(int n)
{
    int        len;
    char    a;

    len = hexlen3(n);
    if (n == -2147483648)
    {
        write (1, "-2147483648", 11);
        return (len);
    }
    else if (n < 0)
    {
        write (1, "-", 1);
        ft_putnbr(-n);
    }
    else if (n < 10)
    {
        a = n + 48;
        write(1, &a, 1);
    }
    else
    {
        ft_putnbr(n / 10);
        ft_putnbr(n % 10);
    }
    return (len);
}

int    ft_putchar(char c)
{
    write(1, &c, 1);
    return (1);
}

static int	ft_print_all(const char *s1, va_list args, int i)
{
	if (s1[i] == 'd')
		return (ft_putnbr(va_arg(args, int)));
	else if (s1[i] == 'c')
		return (ft_putchar(va_arg(args, int)));
	else if (s1[i] == 's')
		return (ft_putstr(va_arg(args, char *)));
	return (0);
}

int	ft_printf(const char *s1, ...)
{	
	int			i;
	int			len;
	va_list		args;

	va_start (args, s1);
	len = 0;
	i = 0;
	while (s1[i] != '\0')
	{
		if (s1[i] == '%')
		{
			i++;
			len += ft_print_all (s1, args, i);
		}
		else
		{
			write (1, &s1[i], 1);
			len++;
		}
		i++;
	}
	va_end (args);
	return (len);
}




