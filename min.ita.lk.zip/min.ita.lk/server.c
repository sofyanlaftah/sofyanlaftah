/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   server.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/07 01:46:16 by alaftah           #+#    #+#             */
/*   Updated: 2022/04/21 05:56:59 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minitalk.h"

void	ft_handler(int sign)
{
	static int i;
	static char ch;
	
	if(sign == SIGUSR1)
		ch |= 1 << i;
	i++;
	if(i == 8)
	{
		ft_printf("%c", ch);
		ch = 0;
		i = 0;
	}
}

int main()
{
	int pid = getpid();

	ft_printf("%d\n", pid);
	while(1)
	{	
		signal(SIGUSR1,ft_handler);
		signal(SIGUSR2, ft_handler);
		pause();
	}
}
