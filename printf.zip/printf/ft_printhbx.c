/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printhbx.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/05 22:06:27 by alaftah           #+#    #+#             */
/*   Updated: 2021/12/10 20:49:04 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include"ft_printf.h"

static int	hexlen(unsigned int nbr)
{
	int	idx;

	idx = 0;
	if (nbr == 0)
		return (1);
	while (nbr)
	{
		nbr = nbr / 16;
		idx++;
	}
	return (idx);
}

int	ft_printhbx(unsigned int nbr)
{
	int		len;
	char	*base;

	len = hexlen(nbr);
	base = "0123456789ABCDEF";
	if (nbr >= 16)
		ft_printhbx(nbr / 16);
	ft_putchar(base[nbr % 16]);
	return (len);
}
