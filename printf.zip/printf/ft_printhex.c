/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printhex.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/06 21:56:28 by alaftah           #+#    #+#             */
/*   Updated: 2021/12/08 00:08:18 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include"ft_printf.h"

static int	hexlen(unsigned int nbr)
{
	int	idx;

	idx = 0;
	if (nbr == 0)
		return (1);
	while (nbr)
	{
		nbr = nbr / 16;
		idx++;
	}
	return (idx);
}

int	ft_printhex(unsigned int nbr)
{
	int		len;
	char	*base;

	len = hexlen(nbr);
	base = "0123456789abcdef";
	if (nbr >= 16)
		ft_printhex(nbr / 16);
	ft_putchar(base[nbr % 16]);
	return (len);
}
