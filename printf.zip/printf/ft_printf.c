/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/15 14:43:59 by alaftah           #+#    #+#             */
/*   Updated: 2021/12/12 01:13:22 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

static int	ft_print_all(const char *s1, va_list args, int i)
{
	if (s1[i] == 'd' || s1[i] == 'i')
		return (ft_putnbr(va_arg(args, int)));
	else if (s1[i] == 'c')
		return (ft_putchar(va_arg(args, int)));
	else if (s1[i] == 's')
		return (ft_putstr(va_arg(args, char *)));
	else if (s1[i] == 'u')
		return (ft_unputnbr(va_arg(args, unsigned int)));
	else if (s1[i] == 'x')
		return (ft_printhex(va_arg(args, unsigned int)));
	else if (s1[i] == 'X')
		return (ft_printhbx(va_arg(args, unsigned int)));
	else if (s1[i] == 'p')
	{
		ft_putstr("0x");
		return (ft_pointer(va_arg(args, unsigned long int)) + 2);
	}
	else if (s1[i] == '%')
		return (ft_putchar('%'));
	return (0);
}

int	ft_printf(const char *s1, ...)
{	
	int			i;
	int			len;
	va_list		args;

	va_start (args, s1);
	len = 0;
	i = 0;
	while (s1[i] != '\0')
	{
		if (s1[i] == '%')
		{
			i++;
			len += ft_print_all (s1, args, i);
		}
		else
		{
			write (1, &s1[i], 1);
			len++;
		}
		i++;
	}
	va_end (args);
	return (len);
}
