/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_unputnbr.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/23 21:47:28 by alaftah           #+#    #+#             */
/*   Updated: 2021/12/08 02:10:46 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include"ft_printf.h"

static int	hexlen(unsigned int nbr)
{
	int	idx;

	idx = 0;
	if (nbr == 0)
		return (1);
	while (nbr)
	{
		nbr = nbr / 10;
		idx++;
	}
	return (idx);
}

int	ft_unputnbr(unsigned int n)
{
	int		len;
	char	a;

	len = hexlen(n);
	if (n < 10)
	{
		a = n + 48;
		write(1, &a, 1);
	}
	else
	{
		ft_unputnbr(n / 10);
		ft_unputnbr(n % 10);
	}
	return (len);
}
