/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/23 21:47:28 by alaftah           #+#    #+#             */
/*   Updated: 2021/12/08 02:08:37 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include"ft_printf.h"

static int	hexlen(int nbr)
{
	int	idx;

	idx = 0;
	if (nbr == 0)
		return (1);
	if (nbr < 0)
	{
		idx++;
		nbr *= -1;
	}
	while (nbr)
	{	
		nbr = nbr / 10;
		idx++;
	}
	return (idx);
}

int	ft_putnbr(int n)
{
	int		len;
	char	a;

	len = hexlen(n);
	if (n == -2147483648)
	{
		write (1, "-2147483648", 11);
		return (len);
	}
	else if (n < 0)
	{
		write (1, "-", 1);
		ft_putnbr(-n);
	}
	else if (n < 10)
	{
		a = n + 48;
		write(1, &a, 1);
	}
	else
	{
		ft_putnbr(n / 10);
		ft_putnbr(n % 10);
	}
	return (len);
}
