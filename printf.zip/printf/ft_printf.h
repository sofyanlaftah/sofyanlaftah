/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/07 15:54:52 by alaftah           #+#    #+#             */
/*   Updated: 2021/12/10 17:23:43 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINTF_H
# define FT_PRINTF_H
# include<stdlib.h>
# include<string.h>
# include<stdio.h>
# include<unistd.h>
# include<fcntl.h>
# include<ctype.h>
# include<stdarg.h>

int		ft_putchar(char c);
int		ft_putstr(char *s);
int		ft_putnbr(int n);
int		ft_unputnbr(unsigned int n);
int		ft_printhex(unsigned int nbr);
int		ft_printhbx(unsigned int nbr);
int		ft_printf(const char *s1, ...);
int		ft_pointer(unsigned long nbr);
#endif