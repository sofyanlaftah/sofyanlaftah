/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_pointer.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/07 23:22:18 by alaftah           #+#    #+#             */
/*   Updated: 2022/04/19 02:29:39 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include"ft_printf.h"

static int	hexlen(unsigned long nbr)
{
	int	idx;

	idx = 0;
	if (nbr == 0)
		idx++;
	while (nbr)
	{
		nbr = nbr / 16;
		idx++;
	}
	return (idx);
}

int	ft_pointer(unsigned long nbr)
{
	int		len;
	char	*base;

	len = hexlen(nbr);
	base = "0123456789abcdef";
	if (nbr >= 16)
		ft_pointer(nbr / 16);
	ft_putchar(base[nbr % 16]);
	return (len);
}
//int main()
//{
//	char *str = "Hello";
//	ft_pointer(str);
//	printf("\n");
//	ft_pointer((char *)str + 1);
//}
//