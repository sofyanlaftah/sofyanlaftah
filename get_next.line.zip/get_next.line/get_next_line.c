/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/02 22:42:14 by alaftah           #+#    #+#             */
/*   Updated: 2022/04/06 20:59:16 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

char	*ft_bfor(char *rest)
{
	int	i;

	i = 0;
	if (!rest[i])
		return (NULL);
	while (rest[i] && rest[i] != '\n')
		i++;
	return (ft_substr(rest, 0, i + 1));
}

char	*ft_after(char *right_str)
{
	int		i;
	int		j;
	char	*str;

	i = 0;
	while (right_str[i] && right_str[i] != '\n')
		i++;
	if (!right_str[i])
	{
		free(right_str);
		return (NULL);
	}
	str = malloc(sizeof(char) * (ft_strlen(right_str) - i + 1));
	if (!str)
		return (NULL);
	i++;
	j = 0;
	while (right_str[i])
		str[j++] = right_str[i++];
	str[j] = '\0';
	free(right_str);
	return (str);
}

char	*ft_read(int fd, char *str)
{
	char	*buff;
	int		i;

	buff = malloc((BUFFER_SIZE + 1) * sizeof(char));
	if (!buff)
		return (NULL);
	i = 1;
	while (!ft_strchr(str, '\n') && i != 0)
	{
		i = read(fd, buff, BUFFER_SIZE);
		if (i == -1)
		{
			free(buff);
			return (NULL);
		}
		buff[i] = '\0';
		str = ft_strjoin(str, buff);
	}
	free(buff);
	return (str);
}

char	*get_next_line(int fd)
{
	char		*line;
	static char	*str;

	if (fd < 0 || BUFFER_SIZE <= 0)
		return (0);
	str = ft_read(fd, str);
	if (!str)
		return (NULL);
	line = ft_bfor(str);
	str = ft_after(str);
	return (line);
}
