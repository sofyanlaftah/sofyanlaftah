/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line_utils.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/02 22:42:36 by alaftah           #+#    #+#             */
/*   Updated: 2022/04/06 21:00:06 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

size_t	ft_strlen(char *s)
{
	size_t	i;

	i = 0;
	if (!s)
		return (0);
	while (s[i] != '\0')
		i++;
	return (i);
}

char	*ft_strchr(char *s, char c)
{
	int	i;

	i = 0;
	if (!s)
		return (NULL);
	if (c == '\0')
		return (&s[ft_strlen(s)]);
	while (s[i] != '\0')
	{
		if (s[i] == c)
			return (&s[i]);
		i++;
	}
	return (NULL);
}

char	*ft_strjoin(char *str, char *buff)
{
	size_t	i;
	size_t	j;
	char	*tmp;

	if (!str)
	{
		str = malloc(1 * sizeof(char));
		str[0] = '\0';
	}
	if (!str || !buff)
		return (NULL);
	tmp = malloc(sizeof(char) * ((ft_strlen(str) + ft_strlen(buff)) + 1));
	if (tmp == NULL)
		return (NULL);
	i = -1;
	j = 0;
	if (str)
		while (str[++i] != '\0')
			tmp[i] = str[i];
	while (buff[j] != '\0')
		tmp[i++] = buff[j++];
	tmp[ft_strlen(str) + ft_strlen(buff)] = '\0';
	free(str);
	return (tmp);
}

char	*ft_substr(char	*s, int start, int len)
{
	int		i;
	char	*str;
	int		size;

	i = 0;
	size = len;
	if (!s)
		return (NULL);
	if ((size_t)start > ft_strlen((char *)s) || s[0] == '\0')
		return (ft_strdup(""));
	if ((size_t)len > ft_strlen(s))
		size = ft_strlen(s) - start + 1;
	str = malloc(sizeof(char) * size + 1);
	if (!str)
		return (NULL);
	while (i < size)
	{
		str[i] = s[start];
		i++;
		start++;
	}
	str[i] = '\0';
	return (str);
}

char	*ft_strdup(char *s)
{
	int		i;
	int		len;
	char	*buff;

	i = 0;
	len = ft_strlen(s);
	buff = malloc(sizeof(char) * len + 1);
	if (!buff)
		return (0);
	while (s[i])
	{
		buff[i] = s[i];
		i++;
	}
	buff[i] = '\0';
	free(s);
	return (buff);
}
