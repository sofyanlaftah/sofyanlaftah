/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   server.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/07 01:46:16 by alaftah           #+#    #+#             */
/*   Updated: 2022/04/19 04:38:55 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minitalk.h"

char	*strjoin(char ch)
{	
	static char *str;
	int i;

	i = 0;
	str = malloc((1) * sizeof(char));
	if(!str)
		return(NULL);
	if(ch)
		{
			str[i] = ch;
		}
	return(str);
}

void	ft_handler(int sign)
{
	static int i;
	static char ch;
	
	if(sign == SIGUSR1)
		ch |= 1 << i;
	i++;
	if(i == 8)
	{
		ft_putstr(strjoin(ch));
		ch = 0;
		i = 0;
	}
}



int main()
{
	int pid = getpid();

	ft_putstr(ft_itoa(pid));
	write(1, "\n", 1);
	while(1)
	{	
		signal(SIGUSR1,ft_handler);
		signal(SIGUSR2, ft_handler);
		pause();
	}
}
