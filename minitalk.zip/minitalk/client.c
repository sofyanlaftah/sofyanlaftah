/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   client.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/19 01:28:23 by alaftah           #+#    #+#             */
/*   Updated: 2022/04/19 03:51:13 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minitalk.h"

void	ft_send_bit(int pid, char ch)
{	
	int	i;

	i = 0;
	while (i < 8)
	{
	if (ch & 1 << i)
		kill (pid, SIGUSR1);
	else
		kill (pid, SIGUSR2);
	i++;
	usleep (100);
	}
}

void	ft_send_char(int pid, char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		ft_send_bit (pid, str[i]);
		i++;
	}
}


    int main(int arc, char *argv[])
{	
	
	int pid;

	if(arc != 3)
	{
		write(1, "somthing is wrong!!\n", 20);
		return(0);
	}
	pid = ft_atoi(argv[1]);
	ft_send_char(pid, argv[2]);
	return(0);
}

