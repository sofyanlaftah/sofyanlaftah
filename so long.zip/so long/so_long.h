/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/12 22:38:29 by alaftah           #+#    #+#             */
/*   Updated: 2022/06/20 04:13:16 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SO_LONG_H
# define SO_LONG_H

# include "mlx.h"
# include"get_next_line.h"
# include <stdlib.h>
# include <string.h>
# include<unistd.h>
# include<stdio.h>
# include <fcntl.h>

typedef struct p_struct {
	char	**str;
	void	*mlx_ptr;
	void	*win_ptr;
	int		hight;
	int		width;
	void	*window;
	void	*image;
	char	*tmp;
	int		x;
	int		y;
	int		i;
	int		j;
	int		m;
}	t_struct;

void	ft_walls_map(char **str);
void	ft_right(char **str);
void	ft_top(char **str);
void	ft_strlen_map(char **str);
void	ft_left(char **str);
void	ft_botom(char **str);
void	put_image(t_struct *p_str);
int		ft_strcmp(char *s1, char *s2);
size_t	ft_strlen(char *s);
void	solong(int fd);
char	**line_join(char **str, char *tmp);
void	ft_map(char **str);
int		ft_hight(char **str);
void	ft_putnbr_fd(int n, int fd);
//char	*ft_substr(char *s, int start, int len);
void	put_ground(t_struct *p_str, int i, int j);
void	put_player(t_struct *p_str, int i, int j);
void	put_wall(t_struct *p_str, int i, int j);
void	put_coin(t_struct *p_str, int i, int j);
void	put_door(t_struct *p_str, int i, int j);
int		ft_hight(char **str);
int		mouse_hook(int mouse);
int		key_hook(int key, t_struct *param);
void	create_new_evant(t_struct *ptr);
void	move_player(int key, t_struct *param);
void	check_coordination(t_struct *messi);
void	move_player_right(t_struct *param);
void	move_player_left(t_struct *param);
void	move_player_up(t_struct *param);
void	move_player_down(t_struct *param);
void	move_player_image_right(t_struct *param);
void	move_player_image_left(t_struct *param);
void	move_player_image_up(t_struct *param);
void	move_player_image_down(t_struct *param);
void	create_new_evant(t_struct *ptr);
int		check_num_of_treasure(char **str);
char	**remove_treasure(char **str, int i, int j);
void	put_enemy(t_struct *p_str, int i, int j);
char	*ft_substr(char *s, unsigned int start, size_t len);
#endif