/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_move_player.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/06 23:44:22 by alaftah           #+#    #+#             */
/*   Updated: 2022/06/19 02:47:27 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include"so_long.h"

void	move_player(int key, t_struct *param)
{
	if (key == 2 && param->str[param->y][param->x + 1] != '1')
		move_player_right(param);
	else if (key == 0 && param->str[param->y][param->x - 1] != '1')
		move_player_left(param);
	else if (key == 13 && param->str[param->y - 1][param->x] != '1')
		move_player_up(param);
	else if (key == 1 && param->str[param->y + 1][param->x] != '1')
		move_player_down(param);
	else if (key == 53)
	{
		write(1, "you did not finished the game\n", 24);
		exit (1);
	}
}
