/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_enemy.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/10 16:11:38 by alaftah           #+#    #+#             */
/*   Updated: 2022/06/19 02:50:31 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include"so_long.h"

void	put_enemy(t_struct *p_str, int i, int j)
{
	p_str->window = mlx_xpm_file_to_image(p_str->mlx_ptr,
			"./img/enemy.xpm", &p_str->hight, &p_str->width);
	mlx_put_image_to_window(p_str->mlx_ptr, p_str->win_ptr,
		p_str->window, j * 75, i * 75);
}
