/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_map_check.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/18 01:08:23 by alaftah           #+#    #+#             */
/*   Updated: 2022/06/19 21:49:25 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include"so_long.h"

void	ft_botom(char **str)
{
	int	i;
	int	j;

	i = 0;
	while (str[i])
		i++;
	i--;
	j = 0;
	while (str[i][j])
	{
		if (str[i][j] != '1')
		{
			write (1, "error\n", 6);
			exit (0);
		}
		j++;
	}
}

void	ft_left(char **str)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (str[i])
	{
		if (str[i][j] != '1')
		{
			write (1, "error\n", 6);
			exit (0);
		}
		i++;
	}
}

void	ft_strlen_map(char **str)
{
	int	j;

	j = 0;
	while (str[j])
	{
		if (ft_strlen(str[0]) != ft_strlen(str[j]))
		{
			write (1, "error\n", 6);
			exit (0);
		}
		j++;
	}
}

void	ft_top(char **str)
{
	int	i;
	int	j;
	int	len;

	i = 0;
	j = 0;
	len = ft_strlen(str[i]);
	while (str[i][j])
	{
		if (str[i][j] != '1')
		{
			write (1, "error\n", 6);
			exit (0);
		}
		j++;
	}
}

void	ft_right(char **str)
{
	int	j;
	int	len;

	j = 0;
	len = ft_strlen(str[j]);
	while (str[j])
	{
		if (str[j][len - 1] != '1')
		{
			write (1, "error\n", 6);
			exit (0);
		}
		j++;
	}
}
