/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   move_image.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/09 00:00:58 by alaftah           #+#    #+#             */
/*   Updated: 2022/06/19 02:48:44 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include"so_long.h"

void	move_player_image_right(t_struct *param)
{
	t_struct	ptr;
	t_struct	img;

	ptr.win_ptr = param->win_ptr;
	ptr.mlx_ptr = param->mlx_ptr;
	ptr.image = mlx_xpm_file_to_image(ptr.mlx_ptr,
			"./img/ground.xpm", &img.hight, &img.width);
	mlx_put_image_to_window(ptr.mlx_ptr, ptr.win_ptr,
		ptr.image, (param->x + 1) * 75, param->y * 75);
	ptr.image = mlx_xpm_file_to_image(ptr.mlx_ptr,
			"./img/hh.xpm", &img.hight, &img.width);
	mlx_put_image_to_window(ptr.mlx_ptr, ptr.win_ptr,
		ptr.image, (param->x + 1) * 75, param->y * 75);
	ptr.image = mlx_xpm_file_to_image(ptr.mlx_ptr,
			"./img/ground.xpm", &img.hight, &img.width);
	mlx_put_image_to_window(ptr.mlx_ptr, ptr.win_ptr,
		ptr.image, param->x * 75, param->y * 75);
}

void	move_player_image_left(t_struct *param)
{
	t_struct	ptr;
	t_struct	img;

	ptr.win_ptr = param->win_ptr;
	ptr.mlx_ptr = param->mlx_ptr;
	ptr.image = mlx_xpm_file_to_image(ptr.mlx_ptr,
			"./img/ground.xpm", &img.hight, &img.width);
	mlx_put_image_to_window(ptr.mlx_ptr, ptr.win_ptr,
		ptr.image, (param->x - 1) * 75, param->y * 75);
	ptr.image = mlx_xpm_file_to_image(ptr.mlx_ptr,
			"./img/player_left.xpm", &img.hight, &img.width);
	mlx_put_image_to_window(ptr.mlx_ptr, ptr.win_ptr,
		ptr.image, (param->x - 1) * 75, param->y * 75);
	ptr.image = mlx_xpm_file_to_image(ptr.mlx_ptr,
			"./img/ground.xpm", &img.hight, &img.width);
	mlx_put_image_to_window(ptr.mlx_ptr, ptr.win_ptr,
		ptr.image, param->x * 75, param->y * 75);
}

void	move_player_image_up(t_struct *param)
{
	t_struct	ptr;
	t_struct	img;

	ptr.win_ptr = param->win_ptr;
	ptr.mlx_ptr = param->mlx_ptr;
	ptr.image = mlx_xpm_file_to_image(ptr.mlx_ptr,
			"./img/ground.xpm", &img.hight, &img.width);
	mlx_put_image_to_window(ptr.mlx_ptr, ptr.win_ptr,
		ptr.image, param->x * 75, (param->y - 1) * 75);
	ptr.image = mlx_xpm_file_to_image(ptr.mlx_ptr,
			"./img/hh.xpm", &img.hight, &img.width);
	mlx_put_image_to_window(ptr.mlx_ptr, ptr.win_ptr,
		ptr.image, param->x * 75, (param->y - 1) * 75);
	ptr.image = mlx_xpm_file_to_image(ptr.mlx_ptr,
			"./img/ground.xpm", &img.hight, &img.width);
	mlx_put_image_to_window(ptr.mlx_ptr, ptr.win_ptr,
		ptr.image, param->x * 75, param->y * 75);
}

void	move_player_image_down(t_struct *param)
{
	t_struct	ptr;
	t_struct	img;

	ptr.win_ptr = param->win_ptr;
	ptr.mlx_ptr = param->mlx_ptr;
	ptr.image = mlx_xpm_file_to_image(ptr.mlx_ptr,
			"./img/ground.xpm", &img.hight, &img.width);
	mlx_put_image_to_window(ptr.mlx_ptr, ptr.win_ptr,
		ptr.image, param->x * 75, (param->y + 1) * 75);
	ptr.image = mlx_xpm_file_to_image(ptr.mlx_ptr,
			"./img/hh.xpm", &img.hight, &img.width);
	mlx_put_image_to_window(ptr.mlx_ptr, ptr.win_ptr,
		ptr.image, param->x * 75, (param->y + 1) * 75);
	ptr.image = mlx_xpm_file_to_image(ptr.mlx_ptr,
			"./img/ground.xpm", &img.hight, &img.width);
	mlx_put_image_to_window(ptr.mlx_ptr, ptr.win_ptr,
		ptr.image, param->x * 75, param->y * 75);
}
