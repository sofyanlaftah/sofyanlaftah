/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_images.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/04 19:19:19 by alaftah           #+#    #+#             */
/*   Updated: 2022/06/19 02:47:47 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

void	put_ground(t_struct *p_str, int i, int j)
{
	p_str->image = mlx_xpm_file_to_image(p_str->mlx_ptr,
			"./img/ground.xpm", &p_str->hight, &p_str->width);
	mlx_put_image_to_window(p_str->mlx_ptr,
		p_str->win_ptr, p_str->image, j * 75, i * 75);
}

void	put_wall(t_struct *p_str, int i, int j)
{
	p_str->window = mlx_xpm_file_to_image(p_str->mlx_ptr,
			"./img/walls.xpm", &p_str->hight, &p_str->width);
	mlx_put_image_to_window(p_str->mlx_ptr,
		p_str->win_ptr, p_str->window, j * 75, i * 75);
}

void	put_coin(t_struct *p_str, int i, int j)
{
	p_str->window = mlx_xpm_file_to_image(p_str->mlx_ptr,
			"./img/mony.xpm", &p_str->hight, &p_str->width);
	mlx_put_image_to_window(p_str->mlx_ptr,
		p_str->win_ptr, p_str->window, j * 75, i * 75);
}

void	put_door(t_struct *p_str, int i, int j)
{
	p_str->window = mlx_xpm_file_to_image(p_str->mlx_ptr,
			"./img/door.xpm", &p_str->hight, &p_str->width);
	mlx_put_image_to_window(p_str->mlx_ptr,
		p_str->win_ptr, p_str->window, j * 75, i * 75);
}

void	put_player(t_struct *p_str, int i, int j)
{
	p_str->window = mlx_xpm_file_to_image(p_str->mlx_ptr,
			"./img/hh.xpm", &p_str->hight, &p_str->width);
	mlx_put_image_to_window(p_str->mlx_ptr,
		p_str->win_ptr, p_str->window, j * 75, i * 75);
}
