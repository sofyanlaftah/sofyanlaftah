/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   move_player.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/08 22:09:49 by alaftah           #+#    #+#             */
/*   Updated: 2022/06/20 04:04:29 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include"so_long.h"

void	check_coordination(t_struct *messi)
{
	messi->i = 0;
	messi->j = 0;
	while (1)
	{
		if (messi->str[messi->i][messi->j] == '\0')
		{
			messi->j = 0;
			messi->i++;
		}
		if (messi->str[messi->i][messi->j] == 'E')
			break ;
		messi->j++;
	}
}

void	move_player_right(t_struct *param)
{
	if ((param->str[param->y][param->x + 1] == 'E'
		&& check_num_of_treasure(param->str) == 0)
		|| (param->str[param->y][param->x + 1] == 'X'))
	{
		param->m++;
		ft_putnbr_fd(param->m, 1);
		write(1, " move\n", 6);
		move_player_image_right(param);
		write(1, "game over ;)", 12);
		system("leaks so_long");
		exit (0);
	}
	else if (param->str[param->y][param->x + 1] != 'E')
	{
		param->m++;
		ft_putnbr_fd(param->m, 1);
		write(1, " move\n", 6);
		move_player_image_right(param);
		param->x++;
	}
}

void	move_player_left(t_struct *param)
{
	if ((param->str[param->y][param->x - 1] == 'E'
		&& check_num_of_treasure(param->str) == 0)
		|| (param->str[param->y][param->x - 1] == 'X'))
	{
		param->m++;
		ft_putnbr_fd(param->m, 1);
		write(1, " move\n", 6);
		move_player_image_left(param);
		write(1, "game over ;)", 12);
		system("leaks so_long");
		exit (0);
	}
	else if (param->str[param->y][param->x - 1] != 'E')
	{
		param->m++;
		ft_putnbr_fd(param->m, 1);
		write(1, " move\n", 6);
		move_player_image_left(param);
		param->x--;
	}
}

void	move_player_up(t_struct *param)
{
	if ((param->str[param->y - 1][param->x] == 'E'
		&& check_num_of_treasure(param->str) == 0)
		|| (param->str[param->y - 1][param->x] == 'X'))
	{
		param->m++;
		ft_putnbr_fd(param->m, 1);
		write(1, " move\n", 6);
		move_player_image_up(param);
		write(1, "game over ;)", 12);
		system("leaks so_long");
		exit (0);
	}
	else if (param->str[param->y - 1][param->x] != 'E')
	{
		param->m++;
		ft_putnbr_fd(param->m, 1);
		write(1, " move\n", 6);
		move_player_image_up(param);
		param->y--;
	}
}

void	move_player_down(t_struct *param)
{
	if ((param->str[param->y + 1][param->x] == 'E'
		&& check_num_of_treasure(param->str) == 0)
		|| (param->str[param->y + 1][param->x] == 'X'))
	{
		param->m++;
		ft_putnbr_fd(param->m, 1);
		write(1, " move\n", 6);
		move_player_image_down(param);
		write(1, "game over ;)", 12);
		system("leaks so_long");
		exit (0);
	}
	else if (param->str[param->y + 1][param->x] != 'E')
	{
		param->m++;
		ft_putnbr_fd(param->m, 1);
		write(1, " move\n", 6);
		move_player_image_down(param);
		param->y++;
	}
}
