/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   solong.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/27 21:16:27 by alaftah           #+#    #+#             */
/*   Updated: 2022/06/19 03:18:28 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include"so_long.h"

int	check_num_of_treasure(char **str)
{
	int	i;
	int	x;
	int	c;

	i = 0;
	x = 0;
	c = 0;
	while (str[i])
	{
		x = 0;
		while (str[i][x])
		{
			if (str[i][x] == 'C')
				c++;
			x++;
		}
		i++;
	}
	return (c);
}

void	create_new_evant(t_struct *ptr)
{
	ptr->x = 0;
	ptr->y = 0;
	while (ptr->str[ptr->y])
	{
		if (ptr->str[ptr->y][ptr->x] == '\0')
		{
			ptr->y++;
			ptr->x = 0;
		}
		if (ptr->str[ptr->y][ptr->x] == 'P')
			break ;
		ptr->x++;
	}
	mlx_hook(ptr->win_ptr, 17, 0, mouse_hook, (void *)0);
	mlx_key_hook(ptr->win_ptr, key_hook, ptr);
}
