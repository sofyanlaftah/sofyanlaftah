/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putimage.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/17 22:35:04 by alaftah           #+#    #+#             */
/*   Updated: 2022/06/19 02:47:51 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

void	put_image(t_struct *p_str)
{
	int	i;
	int	j;

	i = 0;
	mlx_new_image(p_str->mlx_ptr, 75, 75);
	while (p_str->str[i] != NULL)
	{
		j = 0;
		while (p_str->str[i][j])
		{
			put_ground(p_str, i, j);
			if (p_str->str[i][j] == 'P')
				put_player(p_str, i, j);
			else if (p_str->str[i][j] == '1')
				put_wall(p_str, i, j);
			else if (p_str->str[i][j] == 'C')
				put_coin(p_str, i, j);
			else if (p_str->str[i][j] == 'E')
				put_door(p_str, i, j);
			else if (p_str->str[i][j] == 'X')
				put_enemy(p_str, i, j);
			j++;
		}
		i++;
	}
}
