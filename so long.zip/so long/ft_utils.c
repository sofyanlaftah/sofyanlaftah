/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_utils.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/27 20:11:29 by alaftah           #+#    #+#             */
/*   Updated: 2022/06/20 04:12:23 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

int	ft_strcmp(char *s1, char *s2)
{
	int		i;

	i = 0;
	while (s1[i] || s2[i])
	{
		if (s1[i] != s2[i])
			return (s1[i] - s2[i]);
		i++;
	}
	return (0);
}

void	ft_putnbr_fd(int n, int fd)
{
	if (n == -2147483648)
	{
		write (fd, "-2147483648", 11);
		return ;
	}
	else if (n < 0)
	{
		write (fd, "-", 1);
		ft_putnbr_fd(-n, fd);
	}
	else if (n < 10)
	{
		n = n + 48;
		write (fd, &n, 1);
	}
	else if (n >= 10)
	{
		ft_putnbr_fd(n / 10, fd);
		ft_putnbr_fd(n % 10, fd);
	}
}

size_t	ft_strlen(char *s)
{
	size_t	i;

	i = 0;
	while (s[i])
		i++;
	return (i);
}

char	*ft_substr(char *s, unsigned int start, size_t len)
{
	unsigned int	i;
	char			*sub_str;

	if (!s)
		return (NULL);
	if (ft_strlen(s) < len)
		len = ft_strlen(s);
	if (start >= ft_strlen(s))
		return (ft_strdup(""));
	i = 0;
	sub_str = (char *)malloc((len + 1) * sizeof(char));
	if (!sub_str)
		return (NULL);
	while (len--)
	{
		sub_str[i] = s[start];
		i++;
		start++;
	}
	sub_str[i] = '\0';
	free(s);
	return (sub_str);
}
//char	*ft_substr(char *s, int start, int len)
//{
//	int		j;
//	char	*dst;
//	int		slen;
//	int		i;
//
//	j = 0;
//	i = 0;
//	if (s == NULL)
//		return (NULL);
//	slen = ft_strlen(s);
//	if (start >= slen)
//		return ("");
//	if (len > slen)
//		len = slen - start;
//	dst = malloc(sizeof(char) * (len + 1));
//	if (dst == NULL)
//		return (NULL);
//	while (i < len && s[i] != '\0')
//	{
//		dst[j] = s[start + i];
//		i++;
//		j++;
//	}
//	dst[j] = '\0';
//	printf("%p\n", s);
//	//free(s);
//	return (dst);
//}
