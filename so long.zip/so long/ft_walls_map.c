/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_walls_map.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/19 00:07:28 by alaftah           #+#    #+#             */
/*   Updated: 2022/06/20 03:06:04 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

void	ft_walls_map(char **str)
{
	if (str[0] == NULL)
	{
		write (1, "pas de map\n", 11);
		exit (0);
	}
	ft_botom(str);
	ft_left(str);
	ft_strlen_map(str);
	ft_top(str);
	ft_right(str);
}
