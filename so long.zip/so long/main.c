/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/27 16:40:28 by alaftah           #+#    #+#             */
/*   Updated: 2022/06/20 04:02:32 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

void	ft_map(char **str)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	if (str[i] == NULL)
	{
		write (1, "il n'ya pas de map\n", 19);
	}
	while (str[i])
	{
		j = 0;
		while (str[i][j])
		{
			if ((str[i][j] != '1') && (str[i][j] != '0') &&
				(str[i][j] != 'E') && (str[i][j] != 'P') &&
				(str[i][j] != 'C') && (str[i][j] != 'X'))
			{
				write (1, "error\n", 6);
				exit (0);
			}
			j++;
		}
		i++;
	}
}

char	**line_join(char **str, char *tmp)
{
	int		i;
	int		j;
	char	**str2;
	int		len2;

	len2 = ft_strlen(tmp);
	j = 0;
	i = 0;
	while (str[i])
		i++;
	str2 = malloc((i + 2) * sizeof(char *));
	while (str[j])
	{
		str2[j] = str[j];
		j++;
	}
	if (tmp[len2 - 1] == '\n')
	{
		tmp = ft_substr(tmp, 0, len2 - 1);
	}
	str2[j] = tmp;
	j++;
	//free(tmp);
	str2[j] = NULL;
	free(str);
	return (str2);
}

void	solong(int fd)
{
	t_struct	p_str;
	int			i;
	char		*tmp;
	int			j;

	i = 0;
	p_str.str = malloc(1 * sizeof(char *));
	p_str.str[i] = NULL;
	while (1)
	{
		tmp = get_next_line(fd);
		if (tmp == NULL)
			break ;
		p_str.str = line_join(p_str.str, tmp);
		//free(tmp);
	}
	ft_walls_map(p_str.str);
	i = ft_strlen(p_str.str[i]);
	j = ft_hight(p_str.str);
	p_str.mlx_ptr = mlx_init();
	p_str.win_ptr = mlx_new_window(p_str.mlx_ptr, i * 75, j * 75, "solong");
	put_image(&p_str);
	p_str.m = 0;
	create_new_evant(&p_str);
	mlx_loop(p_str.mlx_ptr);
}

int	main(int ac, char **av)
{
	int	s_len;
	int	fd;

	if (ac != 2)
	{
		write (1, "error\n", 6);
		return (0);
	}
	else
	{
		fd = open(av[1], O_RDONLY);
		s_len = ft_strlen(av[1]);
		if (ft_strcmp(av[1] + s_len - 4, ".ber") != 0)
		{
			write (1, "error\n", 6);
			return (0);
		}
		solong(fd);
	}
}
