/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/23 18:31:20 by alaftah           #+#    #+#             */
/*   Updated: 2021/11/29 02:57:54 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	ft_len_s(char const *s, char c)
{
	int		count;
	int		i;

	i = 0;
	count = 0;
	while (s[i])
	{
		while (s[i] == c)
			i++;
		if (s[i] != c && s[i])
				count++;
		while (s[i] != c && s[i])
			i++;
	}
	return (count);
}

char	**ft_split(char const *s, char c)
{
	int		compt;
	int		i;
	char	**dst;
	int		len;
	int		res;

	i = 0;
	res = 0;
	if (!s)
		return (NULL);
	len = ft_len_s(s, c);
	dst = malloc(sizeof(char *) * (len + 1));
	if (!dst)
		return (NULL);
	while (res < len)
	{
		while (s[i] == c && s[i])
			i++;
		compt = i;
		while (s[i] != c && s[i])
			i++;
		dst[res++] = ft_substr (s, compt, i - compt);
	}
	dst[res] = NULL;
	return (dst);
}
