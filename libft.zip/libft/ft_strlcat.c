/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/13 17:17:51 by alaftah           #+#    #+#             */
/*   Updated: 2021/11/27 22:57:55 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcat(char *dst, const char *src, size_t dstsize)
{
	size_t		i;
	size_t		t1;
	size_t		t2;

	i = 0;
	if (!dst && !dstsize)
		return (ft_strlen(src));
	t1 = ft_strlen(dst);
	t2 = ft_strlen(src);
	if (dstsize <= t1)
		return (t2 + dstsize);
	while (src[i] && t1 + i < dstsize - 1)
	{
		dst[t1 + i] = src[i];
		i++;
	}
	dst[t1 + i] = '\0';
	return (t1 + t2);
}
