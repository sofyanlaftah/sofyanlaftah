/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_striteri.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/27 20:47:45 by alaftah           #+#    #+#             */
/*   Updated: 2021/11/27 23:14:54 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include"libft.h"

void	ft_striteri(char *s, void (*f)(unsigned int, char*))
{
	unsigned int	h;

	h = 0;
	if (!s)
		return ;
	while (s[h])
	{
		f(h, &s[h]);
		h++;
	}
}
