/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/18 20:09:41 by alaftah           #+#    #+#             */
/*   Updated: 2022/02/15 16:21:47 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include"libft.h"
char *ft_substr(char const *s, unsigned int start, size_t len)
{
    size_t  j = 0;
    char *dst;
    size_t slen;
    size_t  i = 0;
    if(s == NULL)
        return(NULL);
    slen = ft_strlen(s);
    if (start >= slen)
        return("");
    if (len > slen)
        len = slen - start;
    dst = malloc(sizeof(char) * (len + 1));
    if (dst == NULL)
        return NULL;
    while (i < len && s[i] != '\0')
    {
        dst[j] = s[start + i];
        i++;
        j++;
    }
    dst[j] = '\0';
        return(dst);
}
int main()
{
	char t1[] = "helloana";
	printf("%s\n", ft_substr(t1, 11, 6));
}