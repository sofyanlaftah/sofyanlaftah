/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strmapi.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/27 17:53:45 by alaftah           #+#    #+#             */
/*   Updated: 2021/11/27 19:33:51 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include"libft.h"

char	*ft_strmapi(char const *s, char (*f)(unsigned int, char))
{
	char	*dst;
	int		i;
	int		h;
	size_t	len_s;

	h = 0;
	i = 0;
	if (!s)
		return (NULL);
	len_s = ft_strlen(s);
	dst = (char *)malloc(sizeof(char) * (len_s + 1));
	if (!dst)
		return (NULL);
	while (len_s--)
	{
		dst[i] = f(h, s[i]);
		i++;
		h++;
	}
	dst[i] = '\0';
	return (dst);
}
