/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/18 23:51:39 by alaftah           #+#    #+#             */
/*   Updated: 2021/11/29 03:10:04 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include"libft.h"

static char	*ft_strcpy(char *s1, char *s2, char *dst)
{	
	int		i;
	int		j;
	size_t	lens1;
	size_t	lens2;	

	i = 0;
	j = 0;
	lens1 = (ft_strlen((char *)s1));
	lens2 = (ft_strlen((char *)s2));
	while (lens1--)
	{
		dst[j++] = s1[i++];
	}
	i = 0;
	while (lens2--)
	{
		dst[j++] = s2[i++];
	}
	dst[j] = '\0';
	return (dst);
}

char	*ft_strjoin(char const *s1, char const *s2)
{
	char	*dst;
	size_t	lens1;
	size_t	lens2;

	if (!s1 && !s2)
		return (NULL);
	if (!s1)
		return (ft_strdup(s2));
	if (!s2)
		return (ft_strdup(s1));
	lens1 = (ft_strlen((char *)s1));
	lens2 = (ft_strlen((char *)s2));
	dst = (char *)malloc((lens1 + lens2 + 1) * (sizeof(char)));
	if (dst == NULL)
		return (NULL);
	dst = ft_strcpy((char *)s1, (char *)s2, dst);
	return (dst);
}
