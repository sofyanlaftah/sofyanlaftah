/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/19 01:14:19 by alaftah           #+#    #+#             */
/*   Updated: 2021/11/22 18:36:16 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strtrim(char const *s1, char const *set)
{
	size_t		i;
	size_t		len_s1;
	char		*dest;

	if (!s1)
		return (NULL);
	len_s1 = ft_strlen(s1);
		i = 0;
	while (s1[i] && ft_strchr(set, s1[i]))
		i++;
	while (s1[len_s1 - 1] && ft_strchr(set, s1[len_s1 - 1]) && len_s1 > i)
		len_s1--;
	dest = (char *)malloc(sizeof(char) * (len_s1 - i + 1));
	if (!dest)
		return (NULL);
	ft_strlcpy(dest, &s1[i], (len_s1 - i + 1));
	return (dest);
}
