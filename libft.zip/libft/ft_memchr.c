/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/16 22:06:21 by alaftah           #+#    #+#             */
/*   Updated: 2022/02/10 20:23:25 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memchr(const void *s, int c, size_t n)
{
	size_t	i;
	int		len_s;

	len_s = ft_strlen((char *)s);
	if (!s)
		return (NULL);
	i = 0;
	while (i < n)
	{
		if ((unsigned char)c == 0)
			return ((unsigned char *)&s[len_s]);
		if (((unsigned char *)s)[i] == (unsigned char)c)
			return ((void *)&s[i]);
		i++;
		len_s--;
	}
	return (NULL);
}
int main()
{
	char s1[] = "laftahj";
	printf("%s",ft_memchr(s1, 't', 3));
	
}