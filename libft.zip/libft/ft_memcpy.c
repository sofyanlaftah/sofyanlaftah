/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/10 21:05:02 by alaftah           #+#    #+#             */
/*   Updated: 2021/11/24 21:38:56 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include"libft.h"

void	*ft_memcpy(void *dst, const void *src, size_t n)
{
	size_t				i;
	unsigned const char	*t1;
	unsigned char		*t2;

	i = 0;
	t1 = (unsigned char *)src;
	t2 = (unsigned char *)dst;
	if (t1 == NULL && t2 == NULL)
		return (NULL);
	while (n)
	{
		t2[i] = t1[i];
			i++;
		n--;
	}
	return (t2);
}
