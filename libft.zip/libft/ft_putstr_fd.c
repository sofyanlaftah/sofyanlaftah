/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr_fd.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/24 19:03:21 by alaftah           #+#    #+#             */
/*   Updated: 2021/11/28 23:01:02 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include"libft.h"

void ft_putstr_fd(char *s, int fd)
{

    int i = 0;
    if (!s)
        return ;
    while(s[i])
    {
        ft_putchar_fd(s[i],fd);
        i++;
    }
        
}
//int main()
//{
//    char t1[] = "hello";
//    int fd = creat("myname.txt",1);
//    ft_putstr_fd(t1,fd);
//}