/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alaftah <alaftah@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/12 22:27:23 by alaftah           #+#    #+#             */
/*   Updated: 2022/02/10 20:32:00 by alaftah          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include"libft.h"

int	ft_memcmp(const void *s1, const void *s2, size_t n)
{
	const unsigned char	*ch;
	const unsigned char	*cch;
	size_t				i;

	i = 0;
	ch = s1;
	cch = s2;
	while (i < n)
	{
		if (ch[i] != cch[i])
		{
			return (ch[i] - cch[i]);
		}
		i++;
	}
	return (0);
}
int main()
{
	const unsigned char	ch[] = "lkhhh";
	const unsigned char	cch[] = "hhhhh";
	printf("%d", ft_memcmp(ch ,cch, 5));
}